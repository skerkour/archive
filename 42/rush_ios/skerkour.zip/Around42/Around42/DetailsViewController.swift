//
//  DetailsViewController.swift
//  Around42
//
//  Created by skserkour on 19/12/14.
//  Copyleft 2014 skerkour. No rights reserved.
//

import UIKit
import MapKit
import CoreLocation

class DetailsViewController: UIViewController, MKMapViewDelegate, CLLocationManagerDelegate {

    @IBOutlet weak var map_view_: MKMapView!
	var location_manager_: CLLocationManager!
	var place_: Places!;
	@IBOutlet weak var subtitle_label_: UILabel!
    @IBOutlet weak var scroll_v_pics_: UIScrollView!
    @IBOutlet weak var description_text_view_: UITextView!

	override func viewDidLoad() {
		super.viewDidLoad();
		
		// map init
		self.map_view_.mapType = MKMapType.Hybrid;
		var location = CLLocationCoordinate2D(latitude: place_.get_lat(), longitude: place_.get_long());
		let span = MKCoordinateSpanMake(g_zoom, g_zoom);
		let region = MKCoordinateRegion(center: location, span: span);
		self.map_view_.setRegion(region, animated: true);
		
		// localization
		self.location_manager_ = CLLocationManager();
		self.location_manager_.delegate = self;
		self.location_manager_.requestAlwaysAuthorization();
		self.location_manager_.desiredAccuracy = kCLLocationAccuracyBest;
		self.location_manager_.distanceFilter = kCLDistanceFilterNone;
		self.location_manager_.startUpdatingLocation();
		
		// pin
		var annotation = MKPointAnnotation();
		annotation.setCoordinate(location);
		annotation.title = place_.get_title();
		annotation.subtitle = place_.get_sub_title();
		self.map_view_.addAnnotation(annotation);
		
		// labels
		self.subtitle_label_.text = place_.get_sub_title();
        
        // description textview
        self.description_text_view_.text = place_.get_desc();
        
        // imgs
		scroll_v_pics_.contentSize = CGSizeMake(self.scroll_v_pics_.bounds.width * 2, self.scroll_v_pics_.bounds.height)
		var x: CGFloat = 0;
		for pic in place_.get_pics() {
			var data = NSData(contentsOfURL: NSURL(string: pic)!)
			var img1 = UIImageView(image: UIImage(data:data!))
			img1.frame = CGRectMake(x, 0, 190, 170)
			//img1.contentMode = UIViewContentMode.ScaleAspectFit
			x += 195
			scroll_v_pics_.addSubview(img1)
		}
		
        /*scroll_v_pics_.contentSize = CGSizeMake(self.scroll_v_pics_.bounds.width * 2, self.scroll_v_pics_.bounds.height)
        var data = NSData(contentsOfURL: NSURL(string: "https://irs2.4sqi.net/img/general/304x304/25943218_ZcBvlyeZY_JhXQz4MaPXGiTG0smwoFZZy8WZjdE9zxk.jpg")!)
        var data2 = NSData(contentsOfURL: NSURL(string: "https://irs3.4sqi.net/img/general/304x304/387_BUgGk7o3fhXFCkD5UEOUZ2pnVwTgRSc9qe5yGWFxULk.jpg")!)
        var img1 = UIImageView(image: UIImage(data:data!))
        var img2 = UIImageView(image: UIImage(data:data2!))
        img1.frame = CGRectMake(0, 0, 190, 200)
        img2.frame = CGRectMake(195, 0, 190, 200)
        scroll_v_pics_.addSubview(img1)
        scroll_v_pics_.addSubview(img2)*/
	}
	
	override func didReceiveMemoryWarning() {
		super.didReceiveMemoryWarning();
		// Dispose of any resources that can be recreated.
	}
	
	@IBAction func mapTypeSelector(sender: AnyObject) {
		switch sender.selectedSegmentIndex {
		case 1:
			self.map_view_.mapType = MKMapType.Satellite;
		case 0:
			self.map_view_.mapType = MKMapType.Standard;
		default:
			self.map_view_.mapType = MKMapType.Hybrid;
		}
	}
	
    @IBAction func flagButtonpressed(sender: AnyObject) {
        var location = CLLocationCoordinate2D(latitude: place_.get_lat(), longitude: place_.get_long());
        let span = MKCoordinateSpanMake(g_zoom, g_zoom);
        let region = MKCoordinateRegion(center: location, span: span);
        self.map_view_.setRegion(region, animated: true);
    }

	@IBAction func locationButtonPressed(sender: AnyObject) {
		println("location requested");
		if (self.location_manager_?.location? != nil) {
			var latValue = self.location_manager_.location.coordinate.latitude;
			var lonValue = self.location_manager_.location.coordinate.longitude;
			
			let location = CLLocationCoordinate2D(latitude: latValue, longitude: lonValue);
			let span = MKCoordinateSpanMake(g_zoom, g_zoom);
			let region = MKCoordinateRegion(center: location, span: span);
			self.map_view_.setRegion(region, animated: true);
		}
	}
	
	func locationManager(manager: CLLocationManager!, didUpdateLocations locations: [AnyObject]!) {
		
	}
	
	func locationManager(manager: CLLocationManager!, didFailWithError error: NSError!) {
		println("Error while updating location " + error.localizedDescription);
	}
}
