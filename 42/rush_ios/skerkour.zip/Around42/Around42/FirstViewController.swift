//
//  FirstViewController.swift
//  Around42
//
//  Created by skserkour on 19/12/14.
//  Copyleft 2014 skerkour. No rights reserved.
//

import UIKit
import MapKit
import CoreLocation

var places_list: [Places] = [];

var g_zoom: Double! {
	get {
		var value = NSUserDefaults.standardUserDefaults().objectForKey("zoom") as? Double
		if value == nil {
			return 0.01
		}
		return value
	}
	set (newValue){
		NSUserDefaults.standardUserDefaults().setObject(newValue, forKey: "zoom")
		NSUserDefaults.standardUserDefaults().synchronize()
	}
}

var g_uname: String! {
	get {
		var value = NSUserDefaults.standardUserDefaults().objectForKey("uname") as? String
		if value == nil {
			return "user"
		}
		return value
	}
	set (newValue){
		NSUserDefaults.standardUserDefaults().setObject(newValue, forKey: "uname")
		NSUserDefaults.standardUserDefaults().synchronize()
	}
}

var g_defaultmap: String = "Hybrid";

class FirstViewController: UIViewController, MKMapViewDelegate, CLLocationManagerDelegate, UIGestureRecognizerDelegate {

	@IBOutlet weak var map_view_: MKMapView!
	var location_manager_: CLLocationManager!
	var dropedPinLat: Double = 0.0;
	var dropedPinLong: Double = 0.0;
    @IBOutlet weak var map_type_selector_: UIBarButtonItem!
	
    override func viewDidLoad() {
		super.viewDidLoad();

		// map init
		self.map_view_.mapType = MKMapType.Hybrid;
        let location = CLLocationCoordinate2D(latitude: 48.8965899, longitude: 2.3185);
        let span = MKCoordinateSpanMake(g_zoom, g_zoom);
        let region = MKCoordinateRegion(center: location, span: span);
        self.map_view_.setRegion(region, animated: true);
		
		// localization
		self.location_manager_ = CLLocationManager();
		self.location_manager_.delegate = self;
		self.location_manager_.requestAlwaysAuthorization();
		self.location_manager_.desiredAccuracy = kCLLocationAccuracyBest;
		self.location_manager_.distanceFilter = kCLDistanceFilterNone;
		self.location_manager_.startUpdatingLocation();
		
		// load places array form plist file
		var saved_array: NSArray = [];
		if let path = NSBundle.mainBundle().pathForResource("placesList", ofType: "plist") {
			saved_array = NSArray(contentsOfFile: path)!;
		}
		serialize_saved_array(saved_array);
	
		// place saved places on the map
		for place in places_list {
			dropPin(place.get_lat(), long: place.get_long(), title: place.get_title(), subtitle: place.get_sub_title());
		
		}
		
		// handle long tap
		let longTap: UILongPressGestureRecognizer = UILongPressGestureRecognizer(target: self, action: "didLongTapMap:")
		longTap.delegate = self
		longTap.numberOfTapsRequired = 0
		longTap.minimumPressDuration = 0.7
		self.map_view_.addGestureRecognizer(longTap)
    }
	
	override func viewWillAppear(animated: Bool) {
		 map_view_.removeAnnotations( map_view_.annotations)
		for place in places_list {
			dropPin(place.get_lat(), long: place.get_long(), title: place.get_title(), subtitle: place.get_sub_title());

		}
	}
	
	
	@IBOutlet var newPinTitleField: UITextField!
	@IBOutlet var newPinSubTitleField: UITextField!
	func addNewPinUser(alert: UIAlertAction!){
		// store the new word
		if newPinTitleField.text != "" && newPinSubTitleField.text != "" {
			println(newPinTitleField.text + " | " + newPinSubTitleField.text);
			dropPin(dropedPinLat, long: dropedPinLong, title: newPinTitleField.text, subtitle: newPinSubTitleField.text)
			
			var pplace: String = "place";
			var ddesc: String = "";
			var ppics: [String] = [];
			var newPlace: Places = Places(PlaceTitle: newPinTitleField.text,
									PlaceSubTitle: newPinSubTitleField.text,
									PlaceLong: dropedPinLong,
									PlaceLat: dropedPinLat,
									Type: pplace,
									Desc: ddesc, Pics:ppics);
			places_list.append(newPlace);
			
			let path = NSBundle.mainBundle().pathForResource("placesList", ofType: "plist")
			var data = NSMutableArray(contentsOfFile: path!)!;
			var tmp = ["lat": dropedPinLat, "long": dropedPinLong, "subtitle": newPinSubTitleField.text,"title": newPinTitleField.text, "type": pplace, "desc": ddesc, "pics": ppics]
			data.addObject(tmp);
			println("------------------------------------------------------------------------------------------");
			//println(data);
			data.writeToFile(path!, atomically: true)
			//data = NSMutableArray(contentsOfFile: path!)!;
			//println(data);
			
			dropedPinLat = 0.0;
			dropedPinLong = 0.0;
		}
	}
	func addnewPinTitleField(textField: UITextField!){
		// add the text field and make the result global
		textField.placeholder = "Title"
		self.newPinTitleField = textField
	}
	func addnewPinSubTitleField(textField: UITextField!){
		// add the text field and make the result global
		textField.placeholder = "Subtitle"
		self.newPinSubTitleField = textField
	}
	
	func didLongTapMap(gestureRecognizer: UIGestureRecognizer) {
		if gestureRecognizer.state != UIGestureRecognizerState.Began {
			return
		}
			// Get the spot that was tapped.
			let tapPoint: CGPoint = gestureRecognizer.locationInView(self.map_view_)
			let touchMapCoordinate: CLLocationCoordinate2D = self.map_view_.convertPoint(tapPoint, toCoordinateFromView: self.map_view_)
			println(touchMapCoordinate.latitude);
			dropedPinLat = touchMapCoordinate.latitude;
			dropedPinLong = touchMapCoordinate.longitude
		
			let newWordPrompt = UIAlertController(title: "Add a new favorite place =)", message: "hell yeah !", preferredStyle: UIAlertControllerStyle.Alert)
			newWordPrompt.addTextFieldWithConfigurationHandler(addnewPinTitleField)
			newWordPrompt.addTextFieldWithConfigurationHandler(addnewPinSubTitleField)
			newWordPrompt.addAction(UIAlertAction(title: "Cancel", style: UIAlertActionStyle.Default, handler: nil))
			newWordPrompt.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.Default, handler: addNewPinUser))
			presentViewController(newWordPrompt, animated: true, completion: nil)
		
	}
	
	func dropPin(lat: Double, long: Double, title: String, subtitle: String) {
		var location = CLLocationCoordinate2D(latitude: lat, longitude: long);
		var annotation = MKPointAnnotation();
		annotation.setCoordinate(location);
		annotation.title = title;
		annotation.subtitle = subtitle;
		self.map_view_.addAnnotation(annotation);
		var anView:MKAnnotationView = mapView(self.map_view_, viewForAnnotation: annotation)
	}

	func mapView(mapView: MKMapView!, viewForAnnotation annotation: MKAnnotation!) -> MKAnnotationView! {
			if annotation is MKUserLocation {
				return nil
			}
			let reuseId = "pin"
			
			var pinView = mapView.dequeueReusableAnnotationViewWithIdentifier(reuseId) as? MKPinAnnotationView
			if pinView == nil {
				pinView = MKPinAnnotationView(annotation: annotation, reuseIdentifier: reuseId)
				pinView!.canShowCallout = true
				pinView!.animatesDrop = true
				if (annotation.title == "Paris" || annotation.title == "San Francisco") {
					pinView!.pinColor = .Purple
				}
				pinView!.rightCalloutAccessoryView = UIImageView(image: UIImage(named: "Next"));
			}
			else {
				pinView!.annotation = annotation
			}
			
			return pinView
	}
	
    override func didReceiveMemoryWarning() {
		super.didReceiveMemoryWarning();
        // Dispose of any resources that can be recreated.
    }
	/*********************************************************************/
	
	func serialize_saved_array(array: NSArray) {
		for pl in array {
			var tmp: Places = Places(PlaceTitle: pl["title"] as String,
				PlaceSubTitle: pl["subtitle"] as String,
				PlaceLong: pl["long"] as Double,
				PlaceLat: pl["lat"] as Double,
				Type: pl["type"] as String,
				Desc: pl["desc"] as String,
				Pics: pl["pics"] as [String]);
			places_list.append(tmp);
		}
	}
	
    @IBAction func mapTypeSelector(sender: AnyObject) {
        switch sender.selectedSegmentIndex {
            case 1:
                self.map_view_.mapType = MKMapType.Satellite;
            case 0:
                self.map_view_.mapType = MKMapType.Standard;
            default:
                self.map_view_.mapType = MKMapType.Hybrid;
        }
    }
	
	@IBAction func locationButtonPressed(sender: AnyObject) {
		println("location requested");
		if (self.location_manager_?.location? != nil) {
			var latValue = self.location_manager_.location.coordinate.latitude;
			var lonValue = self.location_manager_.location.coordinate.longitude;

			setMapViewlocation(lonValue, lat: latValue);
		}
	}
	
	func setMapViewlocation(long: Double, lat: Double) {
		let location = CLLocationCoordinate2D(latitude: lat, longitude: long);
		let span = MKCoordinateSpanMake(g_zoom, g_zoom);
		let region = MKCoordinateRegion(center: location, span: span);
		self.map_view_.setRegion(region, animated: true);
	}
	
	func locationManager(manager: CLLocationManager!, didUpdateLocations locations: [AnyObject]!) {
		
	}
	
	func locationManager(manager: CLLocationManager!, didFailWithError error: NSError!) {
		println("Error while updating location " + error.localizedDescription);
	}
	
}