//
//  InfosViewController.swift
//  Around42
//
//  Created by skserkour on 19/12/14.
//  Copyleft 2014 skerkour. No rights reserved.
//

import UIKit

class InfosViewController: UIViewController {
	
	@IBAction func github_button_(sender: AnyObject) {
		UIApplication.sharedApplication().openURL(NSURL(string: "https://github.com/z0mbie42")!)
	}
	
	@IBAction func mail_button_(sender: AnyObject) {
		UIApplication.sharedApplication().openURL(NSURL(string: "mailto:42olol@gmail.com")!)
	}
}
