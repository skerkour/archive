//
//  Places.swift
//  Around42
//
//  Created by skserkour on 19/12/14.
//  Copyleft 2014 skerkour. No rights reserved.
//

import UIKit

struct PlacecCoords {
	var lat: Double = 0.0;
	var long: Double = 0.0;
}

class Places: NSObject {
	
	var title_: String;
	var sub_title_: String;
	var coords_ = PlacecCoords();
	var	type_: String;
	var	pics_: [String];
	var desc_: String;
	
	init (PlaceTitle title: String,
			PlaceSubTitle subtitle: String,
			PlaceLong long: Double,
			PlaceLat lat: Double,
			Type type: String,
			Desc desc: String,
			Pics pics: [String]) {
		self.title_ = title;
		self.sub_title_ =  subtitle;
		self.coords_.long = long;
		self.coords_.lat = lat;
		self.type_ = type;
		self.desc_ = desc;
		self.pics_ = pics;
	}
	
	func set_title(title: String) {
		self.title_ = title;
	}
	func get_title() -> String {
		return (self.title_);
	}
	
	func set_type(type: String) {
		self.type_ = type;
	}
	func get_type() -> String {
		return (self.type_);
	}
	
	func set_desc(desc: String) {
		self.desc_ = desc;
	}
	func get_desc() -> String {
		return (self.desc_);
	}
	
	func set_pics(pics: [String]) {
		self.pics_ = pics;
	}
	func get_pics() -> [String] {
		return (self.pics_);
	}
	
	func set_sub_title(sub_title: String) {
		self.sub_title_ = sub_title;
	}
	func get_sub_title() -> String {
		return (self.sub_title_);
	}

	func set_coords(lat: Double, long: Double) {
		self.coords_.lat = lat;
		self.coords_.long = long;
	}
	func get_coords() -> PlacecCoords {
		return (self.coords_);
	}
	func get_lat() -> Double {
		return (self.coords_.lat);
	}
	func get_long() -> Double {
		return (self.coords_.long);
	}
}
