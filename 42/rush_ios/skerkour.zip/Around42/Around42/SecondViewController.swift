//
//  SecondViewController.swift
//  Around42
//
//  Created by skerkour on 19/12/14.
//  Copyleft 2014 skerkour. No rights reserved.
//

import UIKit

class SecondViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
	
	var list_nb_of_sections_: Int = 1;
	
    @IBOutlet weak var tv_saved_places_: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
       // self.places_table_view_. = UIEdgeInsetMake(20, 0, 0, 0);
	
		tv_saved_places_.tableHeaderView = UIImageView(image: UIImage(named: "507510019"));
		tv_saved_places_.contentInset.top = -258;
    }
	
    override func didReceiveMemoryWarning() {
		super.didReceiveMemoryWarning();
        // Dispose of any resources that can be recreated.
    }

	required init(coder aDecoder: NSCoder) {
		super.init(coder: aDecoder);
	}
	
	func numberOfSectionsInTableView(tableView: UITableView) -> Int {
		return (self.list_nb_of_sections_);
	}
	
	func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
		return (places_list.count);
	}
	
	func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool {
		return true
	}
	
	func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
		if editingStyle == UITableViewCellEditingStyle.Delete {
			places_list.removeAtIndex(indexPath.row)
			tableView.reloadData()
			
			let path = NSBundle.mainBundle().pathForResource("placesList", ofType: "plist")
			var data = NSMutableArray();
			for pl in places_list {
				var tmp = ["lat": pl.get_lat(), "long": pl.get_long(), "subtitle": pl.get_sub_title(),"title": pl.get_title(), "type": pl.get_type(), "desc": pl.get_desc(), "pics": pl.get_pics()]
				data.addObject(tmp);
			}
			data.writeToFile(path!, atomically: true)
		}
	}
	
	func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
		var cell = UITableViewCell(style: UITableViewCellStyle.Default, reuseIdentifier: "Cell");
		cell.textLabel.text = places_list[indexPath.row].get_title();
		cell.accessoryType = UITableViewCellAccessoryType.DisclosureIndicator;
		return (cell);
	}
	
	func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
		println("\(places_list[indexPath.row].get_title()) (lat: \(places_list[indexPath.row].get_lat()), long: \(places_list[indexPath.row].get_long()))")
		performSegueWithIdentifier("ShowDetailMap", sender: indexPath);
		//self.tabBarController?.selectedIndex = 0
		//(self.tabBarController?.selectedViewController as FirstViewController).setMapViewlocation(places_list[indexPath.row].get_long(), lat: places_list[indexPath.row].get_lat())
	}
	
	override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
		if segue.identifier == "ShowDetailMap" {
			var detailMap: DetailsViewController = segue.destinationViewController as DetailsViewController;
			detailMap.place_ = places_list[(sender as NSIndexPath).row];
			detailMap.navigationItem.title = detailMap.place_.get_title();
		}
	}
	
	/*********************************************************************************************************/
	
	func set_list_nb_of_sections(nb: Int) {
		if (nb >= 0) {
			self.list_nb_of_sections_ = nb;
		}
	}
	func get_list_nb_of_sections() -> Int {
		return (self.list_nb_of_sections_);
	}
	
}

