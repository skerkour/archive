//
//  SettingsViewController.swift
//  Around42
//
//  Created by skserkour on 19/12/14.
//  Copyleft 2014 skerkour. No rights reserved.
//

import UIKit

class SettingsViewController: UIViewController {
	
    @IBOutlet weak var zoom_selector_: UISlider!
    
	override func viewDidLoad() {
		zoom_selector_.value = Float(g_zoom) * 100.0;
	}
	
    @IBAction func zoom_selector_changed(sender: AnyObject) {
		g_zoom = Double(zoom_selector_.value) / 100.0;
    }
    @IBAction func mapTypeSelector_settings(sender: AnyObject) {
		switch sender.selectedSegmentIndex {
        case 0:
            g_defaultmap = "Standard";
		case 1:
			g_defaultmap = "Satellite";
		default:
			g_defaultmap = "Hybrid";
		}
        println(g_defaultmap);
	}
    
}
